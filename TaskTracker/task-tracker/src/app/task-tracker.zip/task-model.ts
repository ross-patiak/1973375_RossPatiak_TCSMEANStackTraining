export interface Task {
    id:string;
    name:string;
    task:string;
    deadline:string;
}